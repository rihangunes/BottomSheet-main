//
//  BottomSheetApp.swift
//  BottomSheet
//
//  Created by Rihan gunes on 26. 08. 2023..
//

import SwiftUI

@main
struct BottomSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
